import type { ComponentType } from "react";
import {
  Image as ImageIcon, FileText, BarChart3, Gift, Clock, QrCode,
} from "lucide-react";

export type Product = {
  slug: string;
  name: string;
  category: string;
  price: string;
  icon: ComponentType<{ className?: string; strokeWidth?: number }>;
  gradient: string;
  features: string[];
  url: string;
  demoUrl: string;
};

export const BUNDLE_URL = "https://payments.cashfree.com/forms?code=unlockeverything";
export const SINGLE_URL = "https://payments.cashfree.com/forms?code=pdfmint";

export const products: Product[] = [
  {
    slug: "imagemint",
    name: "ImageMint",
    category: "Image Tools SaaS",
    price: "₹99",
    icon: ImageIcon,
    gradient: "from-violet-500 via-purple-500 to-fuchsia-500",
    url: SINGLE_URL,
    demoUrl: "https://run-it-smoothly.vercel.app",
    features: ["Compress Image","Resize Image","Crop Image","Rotate Image","AI Upscaler","Remove Background","Blur Face","PNG Converter","JPG Converter","WebP Converter","Collage Maker","Watermark Tool","Thumbnail Creator","Face Enhance"],
  },
  {
    slug: "pdfmint",
    name: "PDFMint",
    category: "PDF Tools SaaS",
    price: "₹99",
    icon: FileText,
    gradient: "from-indigo-500 via-violet-500 to-purple-500",
    url: SINGLE_URL,
    demoUrl: "https://pixel-perfect-implementation-rho.vercel.app",
    features: ["Merge PDF","Split PDF","Compress PDF","JPG To PDF","PNG To PDF","PDF To JPG","PDF To PNG","Protect PDF","Unlock PDF","Extract Text","Word To PDF"],
  },
  {
    slug: "seomint",
    name: "SEOMint",
    category: "SEO SaaS",
    price: "₹99",
    icon: BarChart3,
    gradient: "from-purple-500 via-fuchsia-500 to-pink-500",
    url: SINGLE_URL,
    demoUrl: "https://seomint-suite.vercel.app",
    features: ["Word Counter","Character Counter","Keyword Density Checker","Meta Generator","Sitemap Generator","Robots Generator","FAQ Schema Generator","JSON Formatter","Password Generator","Content Generator"],
  },
  {
    slug: "givemint",
    name: "GiveMint",
    category: "Giveaway SaaS",
    price: "₹99",
    icon: Gift,
    gradient: "from-fuchsia-500 via-pink-500 to-rose-500",
    url: SINGLE_URL,
    demoUrl: "https://givemint-viral-giveaways.vercel.app",
    features: ["Spin Wheel","Random Picker","Secret Santa","Coin Flip","Dice Roller","Team Generator","Certificate Generator","Scratch Card"],
  },
  {
    slug: "timemint",
    name: "TimeMint",
    category: "Time Tools SaaS",
    price: "₹99",
    icon: Clock,
    gradient: "from-blue-500 via-indigo-500 to-violet-500",
    url: SINGLE_URL,
    demoUrl: "https://gentle-run.vercel.app",
    features: ["World Clock","Alarm","Timer","Stopwatch","Pomodoro","Meeting Planner","Date Calculator","Age Calculator"],
  },
  {
    slug: "qrmint",
    name: "QRMint",
    category: "QR Code SaaS",
    price: "₹99",
    icon: QrCode,
    gradient: "from-violet-500 via-purple-500 to-indigo-500",
    url: SINGLE_URL,
    demoUrl: "https://pixel-perfect-replica-coral.vercel.app",
    features: ["URL QR","Text QR","Email QR","WiFi QR","WhatsApp QR","Phone QR","Payment QR","Event QR","Logo Upload","Custom Colors","SVG Export","PDF Export"],
  },
];
