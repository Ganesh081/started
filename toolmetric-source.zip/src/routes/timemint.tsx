import { createFileRoute } from "@tanstack/react-router";
import { ProductDetail } from "@/components/ProductDetail";
import { products } from "@/lib/products";

export const Route = createFileRoute("/timemint")({
  head: () => ({
    meta: [
      { title: "TimeMint — Time Tools SaaS Source Code | ToolMetric" },
      { name: "description", content: "Buy TimeMint — a complete time tools SaaS source code template with world clock, alarm, timer, stopwatch, pomodoro and more. Built with React, TypeScript & Tailwind." },
      { property: "og:title", content: "TimeMint — Time Tools SaaS Source Code | ToolMetric" },
      { property: "og:description", content: "Complete time tools SaaS template with 8+ features. Launch your own productivity business today." },
    ],
    links: [{ rel: "canonical", href: "/timemint" }],
  }),
  component: () => {
    const product = products.find((p) => p.slug === "timemint")!;
    return <ProductDetail product={product} />;
  },
});
