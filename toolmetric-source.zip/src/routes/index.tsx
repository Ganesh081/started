import { createFileRoute, Link } from "@tanstack/react-router";
import { motion } from "framer-motion";
import {
  ArrowRight, Check, Sparkles, Zap, ShieldCheck, Download, Code2,
  Smartphone, Search, Rocket, Infinity as InfinityIcon, RefreshCw,
  Image as ImageIcon, FileText, BarChart3, Gift, Clock, QrCode,
  Menu, X, Star, ChevronDown,
} from "lucide-react";
import { useState } from "react";
import { products, BUNDLE_URL, SINGLE_URL, type Product } from "@/lib/products";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ToolMetric — Premium SaaS Source Code Templates" },
      { name: "description", content: "Buy ready-made SaaS source code templates (ImageMint, PDFMint, SEOMint, GiveMint, TimeMint, QRMint). Launch your own SaaS business today. Bundle from ₹299." },
      { property: "og:title", content: "ToolMetric — Premium SaaS Source Code Templates" },
      { property: "og:description", content: "6 production-ready SaaS templates with React, TypeScript & Tailwind. Lifetime access, commercial license." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});


const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: { opacity: 1, y: 0 },
};

function Header() {
  const [open, setOpen] = useState(false);
  const nav = [
    { label: "Home", href: "#home" },
    { label: "Products", href: "#products" },
    { label: "Pricing", href: "#pricing" },
    { label: "FAQ", href: "#faq" },
    { label: "Contact", href: "#contact" },
  ];
  return (
    <header className="sticky top-0 z-50 w-full">
      <div className="glass border-b border-white/40">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
          <a href="#home" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-brand shadow-soft">
              <Sparkles className="h-5 w-5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Tool<span className="text-gradient-brand">Metric</span>
            </span>
          </a>
          <nav className="hidden items-center gap-8 lg:flex">
            {nav.map((n) => (
              <a key={n.label} href={n.href} className="text-sm font-medium text-slate-600 transition hover:text-slate-900">
                {n.label}
              </a>
            ))}
          </nav>
          <div className="hidden items-center gap-3 lg:flex">
            <a href="#products" className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:shadow-sm">
              Browse Templates
            </a>
            <a href={BUNDLE_URL} className="rounded-full bg-gradient-brand px-5 py-2 text-sm font-semibold text-white shadow-soft transition hover:shadow-glow">
              Get Bundle
            </a>
          </div>
          <button className="lg:hidden" onClick={() => setOpen(!open)} aria-label="menu">
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
        {open && (
          <div className="border-t border-white/40 bg-white/80 px-5 py-4 lg:hidden">
            <div className="flex flex-col gap-3">
              {nav.map((n) => (
                <a key={n.label} href={n.href} onClick={() => setOpen(false)} className="text-sm font-medium text-slate-700">
                  {n.label}
                </a>
              ))}
              <a href={BUNDLE_URL} className="mt-2 rounded-full bg-gradient-brand px-5 py-2.5 text-center text-sm font-semibold text-white">
                Get Bundle ₹299
              </a>
            </div>
          </div>
        )}
      </div>
    </header>
  );
}

function FloatingCard({ icon: Icon, label, sub, delay, className }: { icon: React.ComponentType<{ className?: string; strokeWidth?: number }>, label: string, sub: string, delay: number, className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: [0, -10, 0] }}
      transition={{ delay, duration: 4, repeat: Infinity, repeatType: "reverse", ease: "easeInOut" }}
      className={`absolute hidden md:flex items-center gap-3 rounded-2xl glass px-4 py-3 shadow-soft ${className}`}
    >
      <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-brand text-white">
        <Icon className="h-5 w-5" />
      </div>
      <div>
        <div className="text-sm font-semibold text-slate-900">{label}</div>
        <div className="text-xs text-slate-500">{sub}</div>
      </div>
    </motion.div>
  );
}

function Hero() {
  return (
    <section id="home" className="relative overflow-hidden grid-bg">
      <div className="mx-auto max-w-7xl px-5 pb-24 pt-16 lg:px-8 lg:pb-32 lg:pt-24">
        <div className="relative mx-auto max-w-4xl text-center">
          <motion.div initial="hidden" animate="visible" variants={fadeUp} transition={{ duration: 0.5 }}
            className="mx-auto inline-flex items-center gap-2 rounded-full border border-violet-200 bg-violet-50/80 px-4 py-1.5 text-xs font-semibold text-violet-700">
            <Sparkles className="h-3.5 w-3.5" /> Launch Ready-Made SaaS Businesses In Minutes
          </motion.div>
          <motion.h1
            initial="hidden" animate="visible" variants={fadeUp} transition={{ duration: 0.6, delay: 0.1 }}
            className="mt-6 text-4xl font-bold leading-[1.1] tracking-tight text-slate-900 sm:text-5xl lg:text-7xl"
            style={{ fontFamily: "'Space Grotesk', sans-serif" }}
          >
            Launch Your Own SaaS<br className="hidden sm:block" /> Business Without{" "}
            <span className="text-gradient-brand">Writing Code</span>
          </motion.h1>
          <motion.p
            initial="hidden" animate="visible" variants={fadeUp} transition={{ duration: 0.6, delay: 0.2 }}
            className="mx-auto mt-6 max-w-2xl text-base text-slate-600 sm:text-lg"
          >
            Get complete SaaS source code templates with beautiful UI, modern architecture,
            responsive design and production-ready features.
          </motion.p>
          <motion.div
            initial="hidden" animate="visible" variants={fadeUp} transition={{ duration: 0.6, delay: 0.3 }}
            className="mt-10 flex flex-col items-center justify-center gap-3 sm:flex-row"
          >
            <a href={BUNDLE_URL} className="group inline-flex items-center gap-2 rounded-full bg-gradient-brand px-7 py-3.5 text-base font-semibold text-white shadow-glow transition hover:scale-[1.02]">
              Get All Templates ₹299
              <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
            </a>
            <a href="#products" className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-7 py-3.5 text-base font-semibold text-slate-800 shadow-sm transition hover:border-slate-300">
              Browse Templates
            </a>
          </motion.div>
          <div className="mt-6 flex items-center justify-center gap-2 text-xs text-slate-500">
            <Check className="h-4 w-4 text-emerald-500" /> One-time payment
            <span className="mx-2">•</span>
            <Check className="h-4 w-4 text-emerald-500" /> Lifetime access
            <span className="mx-2">•</span>
            <Check className="h-4 w-4 text-emerald-500" /> Commercial license
          </div>

          {/* Floating product cards */}
          <FloatingCard icon={ImageIcon} label="ImageMint" sub="Image Tools" delay={0} className="left-[-2rem] top-12" />
          <FloatingCard icon={FileText} label="PDFMint" sub="PDF Tools" delay={0.4} className="right-[-2rem] top-20" />
          <FloatingCard icon={BarChart3} label="SEOMint" sub="SEO Tools" delay={0.8} className="-left-12 bottom-10" />
          <FloatingCard icon={Gift} label="GiveMint" sub="Giveaway" delay={1.2} className="-right-10 bottom-4" />
          <FloatingCard icon={Clock} label="TimeMint" sub="Time Tools" delay={1.6} className="left-12 -bottom-16" />
          <FloatingCard icon={QrCode} label="QRMint" sub="QR Codes" delay={2} className="right-16 -bottom-20" />
        </div>

        {/* Hero mockup */}
        <motion.div
          initial={{ opacity: 0, y: 60 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="relative mx-auto mt-40 max-w-5xl"
        >
          <div className="absolute inset-0 -z-10 rounded-3xl bg-gradient-brand opacity-20 blur-3xl" />
          <div className="overflow-hidden rounded-3xl border border-white/60 bg-white shadow-glow">
            <div className="flex items-center gap-1.5 border-b border-slate-100 bg-slate-50 px-4 py-3">
              <div className="h-3 w-3 rounded-full bg-rose-400" />
              <div className="h-3 w-3 rounded-full bg-amber-400" />
              <div className="h-3 w-3 rounded-full bg-emerald-400" />
              <div className="ml-4 rounded-md bg-white px-3 py-1 text-xs text-slate-500">toolmetric.in/dashboard</div>
            </div>
            <div className="grid gap-4 bg-gradient-soft p-8 md:grid-cols-3">
              {products.slice(0,6).map((p) => (
                <div key={p.name} className="rounded-2xl bg-white p-5 shadow-card">
                  <div className={`flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br ${p.gradient} text-white`}>
                    <p.icon className="h-5 w-5" />
                  </div>
                  <div className="mt-3 text-sm font-semibold text-slate-900">{p.name}</div>
                  <div className="text-xs text-slate-500">{p.features.length}+ tools</div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function TrustSection() {
  const items = [
    { num: "6", label: "Premium Templates" },
    { num: "100+", label: "Built-In Tools" },
    { num: "∞", label: "Lifetime Access" },
    { num: "1×", label: "One-Time Payment" },
    { num: "✓", label: "Commercial License" },
    { num: "⚡", label: "Instant Download" },
  ];
  return (
    <section className="border-y border-slate-100 bg-white py-12">
      <div className="mx-auto grid max-w-7xl grid-cols-2 gap-6 px-5 md:grid-cols-3 lg:grid-cols-6 lg:px-8">
        {items.map((it, i) => (
          <motion.div key={i} initial={{ opacity:0, y:10 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true }} transition={{ delay: i*0.05 }} className="text-center">
            <div className="text-2xl font-bold text-gradient-brand md:text-3xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{it.num}</div>
            <div className="mt-1 text-xs font-medium text-slate-500 md:text-sm">{it.label}</div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

function ProductCard({ p, i }: { p: Product; i: number }) {
  const Icon = p.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.5, delay: i * 0.05 }}
      whileHover={{ y: -6 }}
      className="group relative flex flex-col overflow-hidden rounded-3xl border border-slate-200/70 bg-white p-6 shadow-card transition hover:shadow-glow"
    >
      <div className={`relative mb-5 flex h-44 items-center justify-center overflow-hidden rounded-2xl bg-gradient-to-br ${p.gradient}`}>
        <div className="absolute inset-0 opacity-30" style={{ backgroundImage: "radial-gradient(circle at 30% 20%, rgba(255,255,255,0.5), transparent 50%)" }} />
        <Icon className="h-20 w-20 text-white/90" strokeWidth={1.5} />
        <div className="absolute bottom-3 left-3 rounded-full bg-white/20 px-3 py-1 text-xs font-medium text-white backdrop-blur">
          {p.category}
        </div>
      </div>
      <div className="flex items-start justify-between gap-3">
        <div>
          <Link to={`/${p.slug}`} className="text-xl font-bold text-slate-900 hover:text-violet-700 transition" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>{p.name}</Link>
          <p className="mt-1 text-sm text-slate-500">{p.features.length}+ powerful tools included</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-slate-900">{p.price}</div>
          <div className="text-xs text-slate-400">one-time</div>
        </div>
      </div>
      <div className="mt-4 flex flex-wrap gap-1.5">
        <span className="rounded-md bg-blue-50 px-2 py-0.5 text-[11px] font-semibold text-blue-700">React</span>
        <span className="rounded-md bg-indigo-50 px-2 py-0.5 text-[11px] font-semibold text-indigo-700">TypeScript</span>
        <span className="rounded-md bg-cyan-50 px-2 py-0.5 text-[11px] font-semibold text-cyan-700">Tailwind</span>
      </div>
      <ul className="mt-4 grid grid-cols-2 gap-1.5 text-xs text-slate-600">
        {p.features.slice(0, 6).map((f) => (
          <li key={f} className="flex items-center gap-1.5">
            <Check className="h-3 w-3 flex-none text-violet-500" /> {f}
          </li>
        ))}
      </ul>
      <div className="mt-6 flex gap-2">
        <a
          href={p.demoUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex-1 rounded-full border border-slate-200 bg-white px-4 py-2.5 text-center text-sm font-semibold text-slate-700 transition hover:border-slate-300"
        >
          Live Demo
        </a>
        <a href={p.url} className="flex-1 rounded-full bg-gradient-brand px-4 py-2.5 text-center text-sm font-semibold text-white shadow-soft transition hover:shadow-glow">
          Buy Now
        </a>
      </div>
    </motion.div>
  );
}

function Products() {
  return (
    <section id="products" className="bg-section py-24">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-violet-200 bg-white px-3 py-1 text-xs font-semibold text-violet-700">
            <Code2 className="h-3.5 w-3.5" /> Premium Templates
          </div>
          <h2 className="mt-4 text-3xl font-bold tracking-tight text-slate-900 sm:text-5xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Six SaaS products,<br />
            <span className="text-gradient-brand">one launch-ready bundle</span>
          </h2>
          <p className="mt-4 text-slate-600">Each template ships with modern UI, full source code, TypeScript types, and production-ready features.</p>
        </div>
        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {products.map((p, i) => <ProductCard key={p.name} p={p} i={i} />)}
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  return (
    <section id="pricing" className="relative overflow-hidden bg-white py-24">
      <div className="absolute inset-0 -z-10 grid-bg" />
      <div className="mx-auto max-w-6xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-5xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Simple pricing.<br /><span className="text-gradient-brand">Massive value.</span>
          </h2>
          <p className="mt-4 text-slate-600">Buy any template for ₹99, or unlock everything with the Ultimate Bundle.</p>
        </div>

        <div className="mt-14 grid items-stretch gap-6 lg:grid-cols-2">
          {/* Single */}
          <motion.div initial={{ opacity:0, y:20 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true }} className="flex flex-col rounded-3xl border border-slate-200 bg-white p-8 shadow-card">
            <div className="text-sm font-semibold text-slate-500">Single Template</div>
            <div className="mt-2 flex items-baseline gap-2">
              <span className="text-5xl font-bold text-slate-900" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>₹99</span>
              <span className="text-sm text-slate-500">one-time</span>
            </div>
            <p className="mt-2 text-sm text-slate-600">Perfect to test the waters with one premium SaaS template.</p>
            <ul className="mt-6 space-y-3 text-sm text-slate-700">
              {["1 Premium Template","Complete Source Code","Commercial License","Lifetime Access","Future Updates","Instant Download"].map((f) => (
                <li key={f} className="flex items-center gap-2"><Check className="h-4 w-4 text-violet-500" /> {f}</li>
              ))}
            </ul>
            <a href={SINGLE_URL} className="mt-8 inline-flex items-center justify-center rounded-full border border-slate-200 bg-white px-6 py-3 text-sm font-semibold text-slate-800 transition hover:border-slate-300">
              Buy Single Template
            </a>
          </motion.div>

          {/* Bundle */}
          <motion.div initial={{ opacity:0, y:20 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true, margin:"-50px" }} transition={{ delay:0.1 }} className="relative flex flex-col overflow-hidden rounded-3xl border border-violet-200 bg-gradient-to-br from-violet-50 via-white to-fuchsia-50 p-8 shadow-glow">
            <div className="absolute -right-2 -top-2 rounded-bl-2xl rounded-tr-3xl bg-gradient-brand px-4 py-1.5 text-xs font-bold text-white shadow-soft">
              🔥 BEST VALUE
            </div>
            <div className="text-sm font-semibold text-violet-700">ToolMetric Ultimate Bundle</div>
            <div className="mt-2 flex items-baseline gap-3">
              <span className="text-5xl font-bold text-gradient-brand" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>₹299</span>
              <span className="text-base text-slate-400 line-through">₹594</span>
              <span className="rounded-full bg-emerald-100 px-2.5 py-0.5 text-xs font-bold text-emerald-700">Save ₹295</span>
            </div>
            <p className="mt-2 text-sm text-slate-600">All 6 premium SaaS templates. Launch unlimited businesses.</p>

            <div className="mt-5 grid grid-cols-2 gap-2">
              {products.map((p) => (
                <div key={p.name} className="flex items-center gap-2 rounded-xl border border-violet-100 bg-white/70 px-3 py-2 text-sm font-semibold text-slate-700">
                  <Check className="h-4 w-4 text-emerald-500" /> {p.name}
                </div>
              ))}
            </div>

            <ul className="mt-5 space-y-2.5 text-sm text-slate-700">
              {["Lifetime Access","Instant Download","Commercial Use","Source Code Included","Future Updates"].map((f) => (
                <li key={f} className="flex items-center gap-2"><Check className="h-4 w-4 text-violet-500" /> {f}</li>
              ))}
            </ul>

            <a href={BUNDLE_URL} className="group mt-8 inline-flex items-center justify-center gap-2 rounded-full bg-gradient-brand px-6 py-3.5 text-base font-bold text-white shadow-glow transition hover:scale-[1.02]">
              Get All 6 Templates ₹299 <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
            </a>
          </motion.div>
        </div>

        {/* Payment description */}
        <div className="mx-auto mt-12 max-w-3xl rounded-3xl border border-slate-200 bg-white p-8 shadow-card">
          <div className="flex items-center gap-2 text-sm font-bold text-violet-700">
            <Rocket className="h-4 w-4" /> ToolMetric Premium Source Code
          </div>
          <p className="mt-2 text-sm text-slate-600">
            Get instant access to premium SaaS source code templates built with React, TypeScript, and Tailwind CSS.
          </p>
          <div className="mt-5 grid gap-2 sm:grid-cols-2">
            {["Complete Source Code Included","Modern UI Design","Fully Responsive","Commercial Use Allowed","Easy Customization","Production Ready","Instant Access After Payment","Lifetime Access","One-Time Payment"].map((f) => (
              <div key={f} className="flex items-center gap-2 text-sm text-slate-700"><Check className="h-4 w-4 text-emerald-500" /> {f}</div>
            ))}
          </div>
          <div className="mt-5 text-xs text-slate-500">No subscriptions. No recurring fees.</div>
        </div>
      </div>
    </section>
  );
}

function WhyUs() {
  const features = [
    { icon: Sparkles, title: "Modern UI", desc: "Beautiful interfaces inspired by Stripe, Linear & Vercel." },
    { icon: Smartphone, title: "Responsive Design", desc: "Looks pixel-perfect on every device, out of the box." },
    { icon: Search, title: "SEO Optimized", desc: "Meta, OG tags, semantic markup — ready to rank." },
    { icon: Zap, title: "Fast Loading", desc: "Optimised builds with Vite for lightning performance." },
    { icon: ShieldCheck, title: "Commercial License", desc: "Use it on unlimited projects, sell to your clients." },
    { icon: Code2, title: "Source Code Included", desc: "Full React + TypeScript codebase, fully editable." },
    { icon: InfinityIcon, title: "Lifetime Access", desc: "Pay once, own forever. No subscriptions." },
    { icon: RefreshCw, title: "Future Updates", desc: "Free updates with new features and improvements." },
  ];
  return (
    <section className="bg-section py-24">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-5xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Why <span className="text-gradient-brand">ToolMetric</span>
          </h2>
          <p className="mt-4 text-slate-600">Everything you need to launch a profitable SaaS business — in one package.</p>
        </div>
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => (
            <motion.div
              key={f.title}
              initial={{ opacity:0, y:20 }}
              whileInView={{ opacity:1, y:0 }}
              viewport={{ once:true }}
              transition={{ delay: i*0.05 }}
              className="group rounded-2xl border border-slate-200/60 bg-white p-6 shadow-card transition hover:-translate-y-1 hover:shadow-glow"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-brand text-white shadow-soft">
                <f.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-base font-bold text-slate-900">{f.title}</h3>
              <p className="mt-1.5 text-sm text-slate-600">{f.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const items = [
    { name: "Arjun Mehta", role: "Indie Developer", text: "Launched my PDF tools site in 2 hours. PDFMint paid for itself on day one. Code quality is genuinely premium." },
    { name: "Priya Sharma", role: "Freelancer", text: "I resell ImageMint to my clients with white-label branding. ₹299 was the best investment of my year." },
    { name: "Rahul Khanna", role: "Startup Founder", text: "We needed a SaaS MVP fast. ToolMetric's bundle saved us 3 months of dev time. UI is Stripe-level." },
    { name: "Sneha Patel", role: "Computer Science Student", text: "Learned more reading these codebases than in 2 semesters. Clean React + TS, beautifully organised." },
    { name: "Vikram Reddy", role: "Agency Owner", text: "Six niche SaaS products for ₹299. We deploy custom versions for our clients. Insane ROI." },
    { name: "Ananya Gupta", role: "Solo Founder", text: "QRMint is running my entire business. Customised the colours, deployed to Vercel, started earning in a week." },
  ];
  return (
    <section className="bg-white py-24">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-5xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Loved by builders<br />
            <span className="text-gradient-brand">shipping real products</span>
          </h2>
        </div>
        <div className="mt-14 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {items.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity:0, y:20 }}
              whileInView={{ opacity:1, y:0 }}
              viewport={{ once:true }}
              transition={{ delay: i*0.05 }}
              className="flex flex-col rounded-3xl border border-slate-200/60 bg-white p-6 shadow-card"
            >
              <div className="flex gap-1 text-amber-400">
                {[...Array(5)].map((_, j) => <Star key={j} className="h-4 w-4 fill-current" />)}
              </div>
              <p className="mt-3 flex-1 text-sm text-slate-700">"{t.text}"</p>
              <div className="mt-5 flex items-center gap-3 border-t border-slate-100 pt-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-brand text-sm font-bold text-white">
                  {t.name.split(" ").map(n=>n[0]).join("")}
                </div>
                <div>
                  <div className="text-sm font-semibold text-slate-900">{t.name}</div>
                  <div className="text-xs text-slate-500">{t.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FAQ() {
  const faqs = [
    { q: "How do I receive the source code?", a: "Immediately after payment you'll receive a download link via email and on the success page. The source code ships as a ZIP with full project structure." },
    { q: "Can I modify the code?", a: "Absolutely. You receive the full, unobfuscated source code. Edit colours, branding, features, add your own — it's yours." },
    { q: "Can I use the templates commercially?", a: "Yes. Every ToolMetric template includes a commercial license. Deploy to production, sell access, or build client work — no extra fees." },
    { q: "Do I get future updates?", a: "Yes, you get lifetime updates. Every new feature, bug fix and improvement is included free." },
    { q: "Do I need coding knowledge?", a: "Basic familiarity with React helps for customisation, but the templates run out of the box. README files include deployment guides for Vercel and Netlify." },
    { q: "How fast is the delivery?", a: "Instant. The download link is shown immediately after a successful Cashfree payment, and sent to your email." },
  ];
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="bg-section py-24">
      <div className="mx-auto max-w-3xl px-5 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-5xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
            Frequently asked <span className="text-gradient-brand">questions</span>
          </h2>
        </div>
        <div className="mt-12 space-y-3">
          {faqs.map((f, i) => (
            <div key={i} className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-card">
              <button onClick={() => setOpen(open === i ? null : i)} className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left">
                <span className="text-base font-semibold text-slate-900">{f.q}</span>
                <ChevronDown className={`h-5 w-5 flex-none text-slate-400 transition ${open === i ? "rotate-180" : ""}`} />
              </button>
              {open === i && (
                <motion.div
                  initial={{ opacity:0, height:0 }} animate={{ opacity:1, height:"auto" }}
                  className="px-6 pb-5 text-sm text-slate-600"
                >{f.a}</motion.div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function FinalCTA() {
  return (
    <section id="contact" className="relative overflow-hidden bg-white py-24">
      <div className="mx-auto max-w-5xl px-5 lg:px-8">
        <motion.div
          initial={{ opacity:0, y:30 }} whileInView={{ opacity:1, y:0 }} viewport={{ once:true }}
          className="relative overflow-hidden rounded-[2rem] bg-gradient-brand p-10 text-center shadow-glow md:p-16"
        >
          <div className="absolute inset-0 opacity-30" style={{ backgroundImage: "radial-gradient(circle at 20% 20%, rgba(255,255,255,0.4), transparent 50%), radial-gradient(circle at 80% 80%, rgba(255,255,255,0.3), transparent 50%)" }} />
          <div className="relative">
            <div className="inline-flex items-center gap-2 rounded-full bg-white/20 px-3 py-1 text-xs font-semibold text-white backdrop-blur">
              <Download className="h-3.5 w-3.5" /> Instant Download
            </div>
            <h2 className="mt-5 text-3xl font-bold text-white sm:text-5xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Get All 6 SaaS Templates<br />For Just ₹299
            </h2>
            <p className="mx-auto mt-4 max-w-xl text-white/90">
              Launch your own SaaS business today with ready-made source code, lifetime access and commercial license.
            </p>
            <a href={BUNDLE_URL} className="group mt-8 inline-flex items-center gap-2 rounded-full bg-white px-8 py-4 text-base font-bold text-violet-700 shadow-2xl transition hover:scale-[1.03]">
              Buy Bundle Now ₹299 <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
            </a>
            <div className="mt-5 text-xs text-white/80">Secure payment via Cashfree • Instant access • Commercial license</div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-white py-12">
      <div className="mx-auto max-w-7xl px-5 lg:px-8">
        <div className="grid gap-10 md:grid-cols-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-brand">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Tool<span className="text-gradient-brand">Metric</span>
              </span>
            </div>
            <p className="mt-3 max-w-xs text-sm text-slate-500">Premium SaaS source code templates to launch your business in minutes.</p>
          </div>
          {[
            { title: "Product", links: ["Products","Pricing","FAQ","Contact"] },
            { title: "Legal", links: ["Privacy Policy","Terms","Refund Policy"] },
            { title: "Contact", links: ["support@toolmetric.in","toolmetric.in"] },
          ].map((col) => (
            <div key={col.title}>
              <div className="text-sm font-bold text-slate-900">{col.title}</div>
              <ul className="mt-3 space-y-2 text-sm text-slate-500">
                {col.links.map((l) => <li key={l}><a href="#" className="hover:text-slate-900">{l}</a></li>)}
              </ul>
            </div>
          ))}
        </div>
        <div className="mt-10 border-t border-slate-100 pt-6 text-center text-xs text-slate-500">
          Copyright © {new Date().getFullYear()} ToolMetric. All rights reserved.
        </div>
      </div>
    </footer>
  );
}

function Index() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <TrustSection />
        <Products />
        <Pricing />
        <WhyUs />
        <Testimonials />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </div>
  );
}
