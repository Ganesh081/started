import { createFileRoute } from "@tanstack/react-router";
import { ProductDetail } from "@/components/ProductDetail";
import { products } from "@/lib/products";

export const Route = createFileRoute("/imagemint")({
  head: () => ({
    meta: [
      { title: "ImageMint — Image Tools SaaS Source Code | ToolMetric" },
      { name: "description", content: "Buy ImageMint — a complete image tools SaaS source code template with compress, resize, crop, AI upscaler, remove background and more. Built with React, TypeScript & Tailwind." },
      { property: "og:title", content: "ImageMint — Image Tools SaaS Source Code | ToolMetric" },
      { property: "og:description", content: "Complete image tools SaaS template with 14+ features. Launch your own image editing business today." },
    ],
    links: [{ rel: "canonical", href: "/imagemint" }],
  }),
  component: () => {
    const product = products.find((p) => p.slug === "imagemint")!;
    return <ProductDetail product={product} />;
  },
});
