import { createFileRoute } from "@tanstack/react-router";
import { ProductDetail } from "@/components/ProductDetail";
import { products } from "@/lib/products";

export const Route = createFileRoute("/pdfmint")({
  head: () => ({
    meta: [
      { title: "PDFMint — PDF Tools SaaS Source Code | ToolMetric" },
      { name: "description", content: "Buy PDFMint — a complete PDF tools SaaS source code template with merge, split, compress, convert, protect and more. Built with React, TypeScript & Tailwind." },
      { property: "og:title", content: "PDFMint — PDF Tools SaaS Source Code | ToolMetric" },
      { property: "og:description", content: "Complete PDF tools SaaS template with 11+ features. Launch your own PDF business today." },
    ],
    links: [{ rel: "canonical", href: "/pdfmint" }],
  }),
  component: () => {
    const product = products.find((p) => p.slug === "pdfmint")!;
    return <ProductDetail product={product} />;
  },
});
