import { createFileRoute } from "@tanstack/react-router";
import { ProductDetail } from "@/components/ProductDetail";
import { products } from "@/lib/products";

export const Route = createFileRoute("/qrmint")({
  head: () => ({
    meta: [
      { title: "QRMint — QR Code SaaS Source Code | ToolMetric" },
      { name: "description", content: "Buy QRMint — a complete QR Code SaaS source code template with URL, text, email, WiFi, WhatsApp, phone, payment, event QR generators. Built with React, TypeScript & Tailwind." },
      { property: "og:title", content: "QRMint — QR Code SaaS Source Code | ToolMetric" },
      { property: "og:description", content: "Complete QR Code SaaS template with 12+ tools. Launch your own QR code business today." },
    ],
    links: [{ rel: "canonical", href: "/qrmint" }],
  }),
  component: () => {
    const product = products.find((p) => p.slug === "qrmint")!;
    return <ProductDetail product={product} />;
  },
});
