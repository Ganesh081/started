import { createFileRoute } from "@tanstack/react-router";
import { ProductDetail } from "@/components/ProductDetail";
import { products } from "@/lib/products";

export const Route = createFileRoute("/seomint")({
  head: () => ({
    meta: [
      { title: "SEOMint — SEO SaaS Source Code | ToolMetric" },
      { name: "description", content: "Buy SEOMint — a complete SEO tools SaaS source code template with word counter, meta generator, sitemap generator, schema generator and more. Built with React, TypeScript & Tailwind." },
      { property: "og:title", content: "SEOMint — SEO SaaS Source Code | ToolMetric" },
      { property: "og:description", content: "Complete SEO tools SaaS template with 10+ features. Launch your own SEO business today." },
    ],
    links: [{ rel: "canonical", href: "/seomint" }],
  }),
  component: () => {
    const product = products.find((p) => p.slug === "seomint")!;
    return <ProductDetail product={product} />;
  },
});
