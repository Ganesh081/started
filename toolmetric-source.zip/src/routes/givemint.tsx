import { createFileRoute } from "@tanstack/react-router";
import { ProductDetail } from "@/components/ProductDetail";
import { products } from "@/lib/products";

export const Route = createFileRoute("/givemint")({
  head: () => ({
    meta: [
      { title: "GiveMint — Giveaway SaaS Source Code | ToolMetric" },
      { name: "description", content: "Buy GiveMint — a complete giveaway SaaS source code template with spin wheel, random picker, secret santa, scratch card and more. Built with React, TypeScript & Tailwind." },
      { property: "og:title", content: "GiveMint — Giveaway SaaS Source Code | ToolMetric" },
      { property: "og:description", content: "Complete giveaway SaaS template with 8+ features. Launch your own viral giveaway business today." },
    ],
    links: [{ rel: "canonical", href: "/givemint" }],
  }),
  component: () => {
    const product = products.find((p) => p.slug === "givemint")!;
    return <ProductDetail product={product} />;
  },
});
