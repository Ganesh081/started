import { createFileRoute } from "@tanstack/react-router";
import { BundlePage } from "@/components/BundlePage";

export const Route = createFileRoute("/bundle")({
  head: () => ({
    meta: [
      { title: "Ultimate Bundle — All 6 SaaS Templates | ToolMetric" },
      { name: "description", content: "Get all 6 ToolMetric premium SaaS source code templates — ImageMint, PDFMint, SEOMint, GiveMint, TimeMint, QRMint — for ₹299. Save ₹295. Lifetime access & commercial license." },
      { property: "og:title", content: "Ultimate Bundle — All 6 SaaS Templates | ToolMetric" },
      { property: "og:description", content: "All 6 premium SaaS templates for ₹299. Launch unlimited businesses with one purchase." },
    ],
    links: [{ rel: "canonical", href: "/bundle" }],
  }),
  component: BundlePage,
});
