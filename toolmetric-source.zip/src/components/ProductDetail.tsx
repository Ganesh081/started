import { motion } from "framer-motion";
import { ArrowLeft, Check, ExternalLink, Sparkles, ArrowRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import type { Product } from "@/lib/products";

export function ProductDetail({ product }: { product: Product }) {
  const Icon = product.icon;
  return (
    <div className="min-h-screen bg-white">
      <header className="sticky top-0 z-50 w-full">
        <div className="glass border-b border-white/40">
          <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-brand shadow-soft">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold tracking-tight" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Tool<span className="text-gradient-brand">Metric</span>
              </span>
            </Link>
            <Link to="/" className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:border-slate-300">
              <ArrowLeft className="h-4 w-4" /> Back to Home
            </Link>
          </div>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden grid-bg pb-20 pt-12">
          <div className="mx-auto max-w-5xl px-5 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center"
            >
              <div className={`mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-to-br ${product.gradient} text-white shadow-glow`}>
                <Icon className="h-10 w-10" strokeWidth={1.5} />
              </div>
              <div className="inline-flex items-center gap-2 rounded-full border border-violet-200 bg-white px-3 py-1 text-xs font-semibold text-violet-700">
                {product.category}
              </div>
              <h1 className="mt-4 text-4xl font-bold tracking-tight text-slate-900 sm:text-6xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                {product.name}
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-600">
                Complete {product.category.toLowerCase()} source code template with {product.features.length}+ tools. Launch today.
              </p>
              <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
                <a
                  href={product.demoUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-7 py-3.5 text-base font-semibold text-slate-800 shadow-sm transition hover:border-slate-300"
                >
                  Live Demo <ExternalLink className="h-4 w-4" />
                </a>
                <a
                  href={product.url}
                  className="group inline-flex items-center gap-2 rounded-full bg-gradient-brand px-7 py-3.5 text-base font-semibold text-white shadow-glow transition hover:scale-[1.02]"
                >
                  Buy Now {product.price} <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
                </a>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="bg-section py-20">
          <div className="mx-auto max-w-5xl px-5 lg:px-8">
            <h2 className="text-center text-2xl font-bold text-slate-900 sm:text-3xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              What&apos;s included
            </h2>
            <div className="mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {product.features.map((f, i) => (
                <motion.div
                  key={f}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.03 }}
                  className="flex items-center gap-3 rounded-2xl border border-slate-200/60 bg-white px-5 py-4 shadow-card"
                >
                  <Check className="h-5 w-5 flex-none text-emerald-500" />
                  <span className="text-sm font-semibold text-slate-700">{f}</span>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-white py-16">
          <div className="mx-auto max-w-3xl px-5 text-center lg:px-8">
            <h3 className="text-xl font-bold text-slate-900" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Built with modern tech
            </h3>
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {["React 19", "TypeScript", "Tailwind CSS", "Vite", "Framer Motion"].map((t) => (
                <span key={t} className="rounded-full bg-slate-100 px-4 py-1.5 text-sm font-semibold text-slate-700">
                  {t}
                </span>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-section py-20">
          <div className="mx-auto max-w-3xl px-5 text-center lg:px-8">
            <h2 className="text-3xl font-bold text-slate-900" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Get {product.name} for {product.price}
            </h2>
            <p className="mt-3 text-slate-600">One-time payment. Lifetime access. Commercial license included.</p>
            <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
              <a href={product.demoUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-7 py-3 text-base font-semibold text-slate-800 shadow-sm transition hover:border-slate-300">
                Try Live Demo <ExternalLink className="h-4 w-4" />
              </a>
              <a href={product.url} className="group inline-flex items-center gap-2 rounded-full bg-gradient-brand px-7 py-3 text-base font-bold text-white shadow-glow transition hover:scale-[1.02]">
                Buy Now {product.price} <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 bg-white py-10">
        <div className="mx-auto max-w-7xl px-5 text-center lg:px-8">
          <div className="flex items-center justify-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-brand">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <span className="text-lg font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Tool<span className="text-gradient-brand">Metric</span>
            </span>
          </div>
          <p className="mt-3 text-sm text-slate-500">Premium SaaS source code templates to launch your business in minutes.</p>
          <div className="mt-6 text-xs text-slate-400">Copyright &copy; {new Date().getFullYear()} ToolMetric. All rights reserved.</div>
        </div>
      </footer>
    </div>
  );
}
