import { motion } from "framer-motion";
import { ArrowLeft, Check, Sparkles, ArrowRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { products, BUNDLE_URL } from "@/lib/products";

export function BundlePage() {
  return (
    <div className="min-h-screen bg-white">
      <header className="sticky top-0 z-50 w-full">
        <div className="glass border-b border-white/40">
          <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4 lg:px-8">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-brand shadow-soft">
                <Sparkles className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold tracking-tight" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Tool<span className="text-gradient-brand">Metric</span>
              </span>
            </Link>
            <Link to="/" className="inline-flex items-center gap-1.5 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:border-slate-300">
              <ArrowLeft className="h-4 w-4" /> Back to Home
            </Link>
          </div>
        </div>
      </header>

      <main>
        <section className="relative overflow-hidden grid-bg pb-20 pt-12">
          <div className="mx-auto max-w-5xl px-5 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center"
            >
              <div className="inline-flex items-center gap-2 rounded-full border border-violet-200 bg-white px-3 py-1 text-xs font-semibold text-violet-700">
                Best Value
              </div>
              <h1 className="mt-4 text-4xl font-bold tracking-tight text-slate-900 sm:text-6xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
                Ultimate Bundle
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-600">
                All 6 premium SaaS templates. Launch unlimited businesses with one purchase.
              </p>
              <div className="mt-6 flex items-center justify-center gap-3">
                <span className="text-5xl font-bold text-gradient-brand" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>₹299</span>
                <span className="text-2xl text-slate-400 line-through">₹594</span>
                <span className="rounded-full bg-emerald-100 px-3 py-1 text-sm font-bold text-emerald-700">Save ₹295</span>
              </div>
              <div className="mt-8">
                <a href={BUNDLE_URL} className="group inline-flex items-center gap-2 rounded-full bg-gradient-brand px-8 py-4 text-base font-bold text-white shadow-glow transition hover:scale-[1.02]">
                  Get Bundle ₹299 <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
                </a>
              </div>
            </motion.div>
          </div>
        </section>

        <section className="bg-section py-20">
          <div className="mx-auto max-w-5xl px-5 lg:px-8">
            <h2 className="text-center text-2xl font-bold text-slate-900 sm:text-3xl" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Everything included
            </h2>
            <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {products.map((p, i) => {
                const Icon = p.icon;
                return (
                  <motion.div
                    key={p.name}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.05 }}
                    className="flex flex-col rounded-2xl border border-slate-200/60 bg-white p-6 shadow-card transition hover:-translate-y-1 hover:shadow-glow"
                  >
                    <div className={`flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br ${p.gradient} text-white shadow-soft`}>
                      <Icon className="h-6 w-6" />
                    </div>
                    <h3 className="mt-4 text-lg font-bold text-slate-900">{p.name}</h3>
                    <p className="mt-1 text-sm text-slate-500">{p.category}</p>
                    <ul className="mt-3 space-y-1.5">
                      {p.features.slice(0, 4).map((f) => (
                        <li key={f} className="flex items-center gap-1.5 text-xs text-slate-600">
                          <Check className="h-3.5 w-3.5 flex-none text-violet-500" /> {f}
                        </li>
                      ))}
                    </ul>
                    <Link
                      to={`/${p.slug}`}
                      className="mt-4 text-sm font-semibold text-violet-600 hover:text-violet-700"
                    >
                      View details →
                    </Link>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="bg-white py-16">
          <div className="mx-auto max-w-3xl px-5 text-center lg:px-8">
            <h3 className="text-xl font-bold text-slate-900" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Built with modern tech
            </h3>
            <div className="mt-6 flex flex-wrap justify-center gap-2">
              {["React 19", "TypeScript", "Tailwind CSS", "Vite", "Framer Motion"].map((t) => (
                <span key={t} className="rounded-full bg-slate-100 px-4 py-1.5 text-sm font-semibold text-slate-700">
                  {t}
                </span>
              ))}
            </div>
          </div>
        </section>

        <section className="bg-section py-20">
          <div className="mx-auto max-w-3xl px-5 text-center lg:px-8">
            <h2 className="text-3xl font-bold text-slate-900" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Get the Ultimate Bundle for ₹299
            </h2>
            <p className="mt-3 text-slate-600">One-time payment. Lifetime access. Commercial license included.</p>
            <div className="mt-8">
              <a href={BUNDLE_URL} className="group inline-flex items-center gap-2 rounded-full bg-gradient-brand px-8 py-4 text-base font-bold text-white shadow-glow transition hover:scale-[1.02]">
                Buy Bundle Now ₹299 <ArrowRight className="h-5 w-5 transition group-hover:translate-x-1" />
              </a>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-slate-200 bg-white py-10">
        <div className="mx-auto max-w-7xl px-5 text-center lg:px-8">
          <div className="flex items-center justify-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-brand">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <span className="text-lg font-bold" style={{ fontFamily: "'Space Grotesk', sans-serif" }}>
              Tool<span className="text-gradient-brand">Metric</span>
            </span>
          </div>
          <p className="mt-3 text-sm text-slate-500">Premium SaaS source code templates to launch your business in minutes.</p>
          <div className="mt-6 text-xs text-slate-400">Copyright &copy; {new Date().getFullYear()} ToolMetric. All rights reserved.</div>
        </div>
      </footer>
    </div>
  );
}
